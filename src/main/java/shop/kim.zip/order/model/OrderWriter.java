package shop.kim.order.model;

public class OrderWriter {
	
	private String cno;

	public String getCno() {
		return cno;
	}

	public void setCno(String cno) {
		this.cno = cno;
	}
	
}
